
import React from 'react';
import type { Post } from '../types';
import Card from './Card';

interface BlogListProps {
  posts: Post[];
  onSelectPost: (post: Post) => void;
}

const BlogList: React.FC<BlogListProps> = ({ posts, onSelectPost }) => {
  return (
    <div id="blog" className="bg-slate-50 py-20 sm:py-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
            Aktuelle Beiträge
          </h2>
          <p className="mt-4 text-lg leading-8 text-slate-600">
            Einblicke, Ratschläge und Geschichten aus unserer Gemeinschaft.
          </p>
        </div>
        <div className="grid gap-10 md:grid-cols-2 lg:grid-cols-3">
          {posts.map((post) => (
            <Card key={post.id} post={post} onSelectPost={onSelectPost} />
          ))}
        </div>
      </div>
    </div>
  );
};

export default BlogList;

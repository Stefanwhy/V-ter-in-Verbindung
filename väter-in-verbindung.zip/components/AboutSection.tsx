
import React from 'react';

const AboutSection: React.FC = () => {
  return (
    <section id="about" className="bg-white py-20 sm:py-28">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
            <h2 className="text-3xl font-bold tracking-tight text-slate-900 sm:text-4xl">
              Unsere Mission
            </h2>
            <p className="mt-4 text-lg leading-8 text-slate-600 max-w-3xl mx-auto">
              Wir glauben, dass jede Vater-Kind-Beziehung das Potenzial hat, stark, liebevoll und widerstandsfähig zu sein. In einer Welt voller Herausforderungen bieten wir einen sicheren Ort für Väter, um sich zu informieren, auszutauschen und zu wachsen.
            </p>
        </div>
        <div className="mt-16 grid grid-cols-1 md:grid-cols-3 gap-12 text-center">
            <div className="flex flex-col items-center">
                <div className="flex items-center justify-center h-16 w-16 rounded-full bg-sky-100 mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-sky-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a2 2 0 01-2-2V4a2 2 0 012-2h8z" />
                    </svg>
                </div>
                <h3 className="text-xl font-semibold text-slate-900">Erfahrungen teilen</h3>
                <p className="mt-2 text-slate-600">Authentische Berichte von Vätern, die ähnliche Situationen gemeistert haben. Sie sind nicht allein.</p>
            </div>
            <div className="flex flex-col items-center">
                <div className="flex items-center justify-center h-16 w-16 rounded-full bg-sky-100 mb-4">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-sky-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
                <h3 className="text-xl font-semibold text-slate-900">Wissen vermitteln</h3>
                <p className="mt-2 text-slate-600">Fundierte Ratschläge und psychologische Einblicke von Experten, um komplexe Dynamiken zu verstehen.</p>
            </div>
            <div className="flex flex-col items-center">
                <div className="flex items-center justify-center h-16 w-16 rounded-full bg-sky-100 mb-4">
                     <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-sky-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M14.828 14.828a4 4 0 01-5.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                </div>
                <h3 className="text-xl font-semibold text-slate-900">Unterstützung bieten</h3>
                <p className="mt-2 text-slate-600">Eine Gemeinschaft, die stärkt und ermutigt. Wir schaffen Verbindungen, die halten.</p>
            </div>
        </div>
      </div>
    </section>
  );
};

export default AboutSection;


import React from 'react';
import type { Post } from '../types';

interface CardProps {
  post: Post;
  onSelectPost: (post: Post) => void;
}

const categoryColors = {
  Erfahrungsbericht: 'bg-sky-100 text-sky-800',
  Ratschlag: 'bg-emerald-100 text-emerald-800',
  Psychologie: 'bg-purple-100 text-purple-800',
  'Recht(e)': 'bg-amber-100 text-amber-800',
};

const Card: React.FC<CardProps> = ({ post, onSelectPost }) => {
  return (
    <div 
      className="flex flex-col rounded-xl shadow-lg overflow-hidden bg-white hover:shadow-2xl transition-shadow duration-300 cursor-pointer group"
      onClick={() => onSelectPost(post)}
    >
      <div className="flex-shrink-0">
        <img className="h-48 w-full object-cover" src={post.imageUrl} alt={post.title} />
      </div>
      <div className="flex-1 p-6 flex flex-col justify-between">
        <div className="flex-1">
          <p className="text-sm font-medium">
            <span className={`inline-flex items-center px-3 py-0.5 rounded-full text-sm font-semibold ${categoryColors[post.category]}`}>
              {post.category}
            </span>
          </p>
          <div className="block mt-4">
            <p className="text-xl font-semibold text-slate-900 group-hover:text-sky-600 transition-colors duration-200">{post.title}</p>
            <p className="mt-3 text-base text-slate-500">{post.excerpt}</p>
          </div>
        </div>
        <div className="mt-6 flex items-center">
          <div className="flex-shrink-0">
            {/* Placeholder for author image */}
            <span className="h-10 w-10 rounded-full bg-slate-200 flex items-center justify-center text-slate-500 font-bold">
              {post.author.charAt(0)}
            </span>
          </div>
          <div className="ml-3">
            <p className="text-sm font-medium text-slate-900">{post.author}</p>
            <div className="flex space-x-1 text-sm text-slate-500">
              <time dateTime={post.date}>{post.date}</time>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Card;
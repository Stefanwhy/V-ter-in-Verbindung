
import React from 'react';

const HeroSection: React.FC = () => {
  return (
    <div className="relative bg-slate-700 pt-24 pb-32 sm:pt-32 sm:pb-40">
      <div className="absolute inset-0">
        <img
          className="w-full h-full object-cover opacity-30"
          src="https://picsum.photos/seed/hero/1920/1080"
          alt="Vater und Kind im Gegenlicht"
        />
        <div className="absolute inset-0 bg-slate-800 mix-blend-multiply" aria-hidden="true" />
      </div>
      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <h1 className="text-4xl font-extrabold tracking-tight text-white sm:text-5xl lg:text-6xl">
          Starke Väter, Starke Kinder.
        </h1>
        <p className="mt-6 max-w-3xl mx-auto text-xl text-slate-200">
          Gemeinsam durch Herausforderungen. Finden Sie Unterstützung, Rat und Erfahrungsberichte für eine erfüllte Vater-Kind-Beziehung.
        </p>
        <div className="mt-10">
          <a
            href="#blog"
            className="bg-sky-600 text-white font-bold py-3 px-8 rounded-lg text-lg hover:bg-sky-700 transition duration-300 transform hover:scale-105"
          >
            Zu den Beiträgen
          </a>
        </div>
      </div>
    </div>
  );
};

export default HeroSection;

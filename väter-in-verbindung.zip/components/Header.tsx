
import React from 'react';

const Header: React.FC = () => {
  return (
    <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-20">
          <div className="flex-shrink-0">
            <a href="#" className="text-2xl font-bold text-slate-900 font-serif">
              Väter in Verbindung
            </a>
          </div>
          <nav className="hidden md:flex md:space-x-8">
            <a href="#" className="text-slate-600 hover:text-sky-600 transition duration-150 ease-in-out font-medium">Startseite</a>
            <a href="#about" className="text-slate-600 hover:text-sky-600 transition duration-150 ease-in-out font-medium">Über uns</a>
            <a href="#blog" className="text-slate-600 hover:text-sky-600 transition duration-150 ease-in-out font-medium">Blog</a>
          </nav>
        </div>
      </div>
    </header>
  );
};

export default Header;

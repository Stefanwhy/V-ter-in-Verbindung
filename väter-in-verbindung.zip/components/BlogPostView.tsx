
import React from 'react';
import type { Post } from '../types';
import ArrowLeftIcon from './icons/ArrowLeftIcon';

interface BlogPostViewProps {
  post: Post;
  onGoBack: () => void;
}

const categoryColors = {
  Erfahrungsbericht: 'bg-sky-100 text-sky-800',
  Ratschlag: 'bg-emerald-100 text-emerald-800',
  Psychologie: 'bg-purple-100 text-purple-800',
  'Recht(e)': 'bg-amber-100 text-amber-800',
};

const BlogPostView: React.FC<BlogPostViewProps> = ({ post, onGoBack }) => {
  return (
    <div className="bg-white py-12 sm:py-16">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="mb-8">
          <button
            onClick={onGoBack}
            className="inline-flex items-center gap-2 text-slate-600 hover:text-sky-700 font-semibold transition-colors duration-200"
          >
            <ArrowLeftIcon className="h-5 w-5" />
            Zurück zur Übersicht
          </button>
        </div>

        <div className="text-center mb-12">
          <span className={`inline-flex items-center px-4 py-1 rounded-full text-base font-semibold ${categoryColors[post.category]}`}>
            {post.category}
          </span>
          <h1 className="mt-4 text-4xl font-bold tracking-tight text-slate-900 sm:text-5xl">
            {post.title}
          </h1>
          <p className="mt-6 text-lg text-slate-500">
            Veröffentlicht von {post.author} am {post.date}
          </p>
        </div>

        <div className="aspect-w-16 aspect-h-9 rounded-xl overflow-hidden shadow-lg mb-12">
          <img
            src={post.imageUrl}
            alt={post.title}
            className="w-full h-full object-cover"
          />
        </div>

        <div className="prose prose-lg lg:prose-xl max-w-none text-slate-700 prose-headings:text-slate-900 prose-p:leading-relaxed prose-a:text-sky-600">
          {post.content.map((paragraph, index) => (
            <p key={index}>{paragraph}</p>
          ))}
        </div>
      </div>
    </div>
  );
};

export default BlogPostView;
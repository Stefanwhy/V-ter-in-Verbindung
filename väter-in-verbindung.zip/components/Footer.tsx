
import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-800 text-white">
      <div className="max-w-7xl mx-auto py-8 px-4 sm:px-6 lg:px-8">
        <div className="text-center text-sm text-slate-400">
          <p>&copy; {new Date().getFullYear()} Väter in Verbindung. Alle Rechte vorbehalten.</p>
          <p className="mt-2">Eine Ressource für starke Väter und glückliche Kinder.</p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
